# Browser Mini DayZ

Progress saving doesn't work.

# [Play in Browser](https://meterpreter57.github.io/minidayz_1.4.1/)

